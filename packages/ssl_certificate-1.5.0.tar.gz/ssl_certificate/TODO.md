TODO
====

* [ ] Fix CentOS `7` support.
* [ ] Document apache template parameters.
* [ ] Generate a CSR.
* [ ] Manage certificate expiration.
* [ ] Add `:delete` action.
* [ ] why-run support.
* [ ] Check generated certificate data in ChefSpec unit tests.
* [ ] Add RSpec library unit tests.
* [ ] Add older Chef versions support (patch lazy).
* [ ] Integrate with test coverage.
* [ ] Use markdown tables in the README.
